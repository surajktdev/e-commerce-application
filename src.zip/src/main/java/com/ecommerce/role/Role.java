package com.ecommerce.role;

public enum Role {ADMIN, SELLER, BUYER;
}
